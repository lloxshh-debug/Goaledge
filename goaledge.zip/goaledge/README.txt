# GoalEdge Setup — 3 Steps

## Step 1 — Get your free API key
1. Go to https://dashboard.api-football.com
2. Sign up (free, no card needed)
3. Copy your API Key

## Step 2 — Deploy to Vercel
1. Go to https://vercel.com → sign up with GitHub (free)
2. Click "Add New Project" → "Upload" → upload this entire folder
3. Before clicking Deploy, go to "Environment Variables" and add:
   - Name:  FOOTBALL_API_KEY
   - Value: (paste your key from Step 1)
4. Click Deploy

## Step 3 — Done!
Vercel gives you a live URL like: https://goaledge.vercel.app
Open it — the app automatically fetches real matches every day.

---
Leagues covered: Premier League, La Liga, Bundesliga, Serie A, Ligue 1, Champions League
Free API limit: 100 requests/day (plenty for personal use)
